package model;
import java.util.ArrayList;
import java.util.List;

public class Partecipante extends Utente {
    private ArrayList<Hackathon> iscrizioniEventi = new ArrayList<>();
    private ArrayList<Team> invitiRicevuti = new ArrayList<>();
    private ArrayList<Team> teams = new ArrayList<>();

    public Partecipante(String ssn, String nome, String cognome, String email, String password, String ruolo) {
        super(ssn, nome, cognome, email, password, ruolo);
    }

    public boolean effettuaIscrizione(Hackathon evento){
        if(evento.getNumMaxIscritti() > evento.getPartecipanti().size()){
            iscrizioniEventi.add(evento);
            return true;
        }
        else
            return false;
    }

    public void creaTeam(String nome, Hackathon evento){
        Team team = new Team(nome, this, evento);
        if(getTeam(evento) == null)
            teams.add(team);
        evento.aggiungiTeam(team);
    }

    public boolean inviaInvito(Partecipante partecipante, Team team){
        if(partecipante.invitiRicevuti.contains(team))
            return false;
        else{
            partecipante.invitiRicevuti.add(team);
            return true;
        }
    }

    public boolean accettaInvito(Team team) {
        if (team == null || team.getEvento() == null) {
            return false; // Invito non valido
        }

        Hackathon evento = team.getEvento();

        // Se il partecipante ha già un team per questo evento, rifiutiamo
        if (getTeam(evento) != null) {
            return false;
        }

        // Se non è iscritto all'evento, iscrivilo
        if (!iscrizioniEventi.contains(evento)) {
            effettuaIscrizione(evento);
        }

        // Aggiungilo al team
        team.aggiungiPartecipante(this);

        // Aggiungilo alla lista dei team personali, evitando duplicati
        if (!teams.contains(team)) {
            teams.add(team);
        }

        invitiRicevuti.remove(team);

        return true;
    }

    public List<Hackathon> getIscrizioniEventi(){
        return iscrizioniEventi;
    }

    public List<Team> getInvitiRicevuti(){
        return invitiRicevuti;
    }

    public Team getTeam(Hackathon evento){
        for(Team t : evento.getListaTeam())
            if(t.getComponenti().contains(this))
                return t;
        return null;
    }

    public List<Team> getTeams(){
        return teams;
    }
}
